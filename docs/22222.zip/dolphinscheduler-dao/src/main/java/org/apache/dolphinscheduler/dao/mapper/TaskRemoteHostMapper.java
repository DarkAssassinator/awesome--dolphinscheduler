package org.apache.dolphinscheduler.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.dolphinscheduler.dao.entity.Environment;
import org.apache.dolphinscheduler.dao.entity.TaskRemoteHost;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * TaskRemoteHost Mapper interfaces
 */
public interface TaskRemoteHostMapper extends BaseMapper<TaskRemoteHost> {

    /**
     * query task remote host by name
     *
     * @param name name
     * @return task remote host
     */
    TaskRemoteHost queryByTaskRemoteHostName(@Param("remoteHostName") String name);

    /**
     * query task remote host by code
     *
     * @param code remote host code
     * @return task remote host
     */
    TaskRemoteHost queryByTaskRemoteHostCode(@Param("remoteHostCode") Long code);

    /**
     * query all task remote host list
     * @return list of task remote host
     */
    List<TaskRemoteHost> queryAllTaskRemoteHostList();

    /**
     * task remote host page
     * @param page page
     * @param searchName searchName
     * @return remote host IPage
     */
    IPage<TaskRemoteHost> queryTaskRemoteHostListPaging(IPage<TaskRemoteHost> page, @Param("searchName") String searchName);


    /**
     * task remote host page by id list
     * @param page page
     * @param ids id list
     * @param searchVal search value
     * @return remote host IPage
     */
    IPage<TaskRemoteHost> queryTaskRemoteHostListPagingByIds(Page<TaskRemoteHost> page, @Param("ids") List<Integer> ids,
                                                       @Param("searchName") String searchVal);

    /**
     * delete task remote host by code
     *
     * @param code code
     * @return int
     */
    int deleteByCode(@Param("code") Long code);

}
