package org.apache.dolphinscheduler.api.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dolphinscheduler.api.dto.TaskRemoteHostDTO;
import org.apache.dolphinscheduler.api.enums.Status;
import org.apache.dolphinscheduler.api.exceptions.ServiceException;
import org.apache.dolphinscheduler.api.service.TaskRemoteHostService;
import org.apache.dolphinscheduler.api.utils.PageInfo;
import org.apache.dolphinscheduler.api.utils.Result;
import org.apache.dolphinscheduler.api.vo.TaskRemoteHostVO;
import org.apache.dolphinscheduler.common.enums.AuthorizationType;
import org.apache.dolphinscheduler.common.enums.UserType;
import org.apache.dolphinscheduler.common.utils.CodeGenerateUtils;
import org.apache.dolphinscheduler.common.utils.CodeGenerateUtils.CodeGenerateException;
import org.apache.dolphinscheduler.dao.entity.TaskRemoteHost;
import org.apache.dolphinscheduler.dao.entity.User;
import org.apache.dolphinscheduler.dao.mapper.TaskRemoteHostMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.apache.dolphinscheduler.api.constants.ApiFuncIdentificationConstant.TASK_REMOTE_HOST_CREATE;
import static org.apache.dolphinscheduler.api.constants.ApiFuncIdentificationConstant.TASK_REMOTE_HOST_DELETE;
import static org.apache.dolphinscheduler.api.constants.ApiFuncIdentificationConstant.TASK_REMOTE_HOST_EDIT;

@Service
public class TaskRemoteHostServiceImpl extends BaseServiceImpl implements TaskRemoteHostService {

    private static final Logger logger = LoggerFactory.getLogger(TaskRemoteHostServiceImpl.class);

    @Autowired
    private TaskRemoteHostMapper taskRemoteHostMapper;

    @Override
    @Transactional
    public int createTaskRemoteHost(User loginUser, TaskRemoteHostDTO taskRemoteHostDTO) {
        checkTaskRemoteHostDTO(taskRemoteHostDTO);

        checkOperatorPermissions(loginUser, null, AuthorizationType.TASK_REMOTE_TASK, TASK_REMOTE_HOST_CREATE);

        if (isExistSameName(taskRemoteHostDTO.getName())) {
            throw new ServiceException(Status.TASK_REMOTE_HOST_EXIST, taskRemoteHostDTO.getName());
        }

        TaskRemoteHost remoteHost = new TaskRemoteHost();
        BeanUtils.copyProperties(taskRemoteHostDTO, remoteHost);
        long remoteHostCode;
        try {
            remoteHostCode = CodeGenerateUtils.getInstance().genCode();
        } catch (CodeGenerateException e) {
            throw new ServiceException(Status.INTERNAL_SERVER_ERROR_ARGS);
        }
        remoteHost.setCode(remoteHostCode);
        remoteHost.setOperator(loginUser.getId());
        remoteHost.setCreateTime(new Date());
        remoteHost.setUpdateTime(new Date());

        int result = taskRemoteHostMapper.insert(remoteHost);
        if (result > 0) {
            permissionPostHandle(AuthorizationType.TASK_REMOTE_TASK, loginUser.getId(),
                    Collections.singletonList(remoteHost.getId()), logger);
            logger.info("Create remote host successes, host name {}.", remoteHost.getName());
        }
        return result;
    }

    @Override
    @Transactional
    public int updateTaskRemoteHost(long code, User loginUser, TaskRemoteHostDTO taskRemoteHostDTO) {
        checkTaskRemoteHostDTO(taskRemoteHostDTO);
        checkOperatorPermissions(loginUser, null, AuthorizationType.TASK_REMOTE_TASK, TASK_REMOTE_HOST_EDIT);

        if (isExistSameName(taskRemoteHostDTO.getName())) {
            throw new ServiceException(Status.TASK_REMOTE_HOST_EXIST, taskRemoteHostDTO.getName());
        }

        TaskRemoteHost taskRemoteHost = taskRemoteHostMapper.queryByTaskRemoteHostCode(code);
        if (taskRemoteHost == null || taskRemoteHost.getCode() != code) {
            throw new ServiceException(Status.TASK_REMOTE_HOST_NOT_FOUND, code);
        }

        BeanUtils.copyProperties(taskRemoteHostDTO, taskRemoteHost);
        taskRemoteHost.setUpdateTime(new Date());
        return taskRemoteHostMapper.updateById(taskRemoteHost);
    }

    @Override
    @Transactional
    public int deleteByCode(long code, User loginUser) {
        checkOperatorPermissions(loginUser, null, AuthorizationType.TASK_REMOTE_TASK, TASK_REMOTE_HOST_DELETE);

        TaskRemoteHost taskRemoteHost = taskRemoteHostMapper.queryByTaskRemoteHostCode(code);
        if (taskRemoteHost == null || taskRemoteHost.getCode() != code) {
            throw new ServiceException(Status.TASK_REMOTE_HOST_NOT_FOUND, code);
        }
        // TODO 需要检查Task是否含有该服务器，否则不能删除

        return taskRemoteHostMapper.deleteByCode(code);
    }

    @Override
    @Transactional
    public List<TaskRemoteHostVO> queryAllTaskRemoteHosts(User loginUser) {
        Set<Integer> ids = resourcePermissionCheckService.userOwnedResourceIdsAcquisition(AuthorizationType.TASK_REMOTE_TASK,
                loginUser.getId(), logger);
        if (ids.isEmpty()) {
            return new ArrayList<>();
        }

        List<TaskRemoteHost> taskRemoteHostList = taskRemoteHostMapper.selectBatchIds(ids);
        List<TaskRemoteHostVO> taskRemoteHostVOList = taskRemoteHostList.stream().map(taskRemoteHost -> {
            TaskRemoteHostVO taskRemoteHostVO = new TaskRemoteHostVO();
            BeanUtils.copyProperties(taskRemoteHost, taskRemoteHostVO);
            return taskRemoteHostVO;
        }).collect(Collectors.toList());

        return taskRemoteHostVOList;
    }

    @Override
    @Transactional
    public PageInfo<TaskRemoteHostVO> queryTaskRemoteHostListPaging(User loginUser, String searchVal, Integer pageNo, Integer pageSize) {
        Page<TaskRemoteHost> page = new Page<>(pageNo, pageSize);
        PageInfo<TaskRemoteHostVO> pageInfo = new PageInfo<>(pageNo, pageSize);
        IPage<TaskRemoteHost> taskRemoteHostIPage;

        if(loginUser.getUserType().equals(UserType.ADMIN_USER)) {
            taskRemoteHostIPage = taskRemoteHostMapper.queryTaskRemoteHostListPaging(page, searchVal);
        } else {
            Set<Integer> ids = resourcePermissionCheckService
                    .userOwnedResourceIdsAcquisition(AuthorizationType.TASK_REMOTE_TASK, loginUser.getId(), logger);
            if (ids.isEmpty()) {
                return pageInfo;
            }
            taskRemoteHostIPage = taskRemoteHostMapper.queryTaskRemoteHostListPagingByIds(page, new ArrayList<>(ids), searchVal);
        }
        pageInfo.setTotal((int) taskRemoteHostIPage.getTotal());

        if (CollectionUtils.isNotEmpty(taskRemoteHostIPage.getRecords())) {
            List<TaskRemoteHostVO> voList = taskRemoteHostIPage.getRecords().stream().map(taskRemoteHost -> {
                TaskRemoteHostVO taskRemoteHostVO = new TaskRemoteHostVO();
                BeanUtils.copyProperties(taskRemoteHost, taskRemoteHostVO);
                return taskRemoteHostVO;
            }).collect(Collectors.toList());
            pageInfo.setTotalList(voList);
        } else {
            pageInfo.setTotalList(new ArrayList<>());
        }
        return pageInfo;
    }

    @Override
    public boolean testConnect(TaskRemoteHostDTO taskRemoteHostDTO) {
        return true;
    }

    @Override
    public boolean verifyTaskRemoteHost(String taskRemoteHostName) {
        if (StringUtils.isEmpty(taskRemoteHostName)) {
            throw new ServiceException(Status.TASK_REMOTE_HOST_IS_NULL);
        }

        TaskRemoteHost taskRemoteHost = taskRemoteHostMapper.queryByTaskRemoteHostName(taskRemoteHostName);
        if (taskRemoteHost != null) {
            throw new ServiceException(Status.TASK_REMOTE_HOST_NAME_EXISTS, taskRemoteHostName);
        }

        return true;
    }

    private boolean isExistSameName(String name) {
        TaskRemoteHost remoteHost = taskRemoteHostMapper.queryByTaskRemoteHostName(name);
        return remoteHost != null && remoteHost.getName().equals(name);
    }

    // TODO
    private void checkTaskRemoteHostDTO(TaskRemoteHostDTO taskRemoteHostDTO) {

    }
}
