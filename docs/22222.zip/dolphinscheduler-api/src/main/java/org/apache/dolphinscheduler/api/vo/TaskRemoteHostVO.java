package org.apache.dolphinscheduler.api.vo;

import java.util.Date;

/**
 * Task Remote Host VO
 */
public class TaskRemoteHostVO {

    private Integer id;

    private String name;

    private String ip;

    private Integer port;

    private String account;

    private String password;

    private String description;

    private Integer operator;

    private Date createTime;

    private Date updateTime;

}
