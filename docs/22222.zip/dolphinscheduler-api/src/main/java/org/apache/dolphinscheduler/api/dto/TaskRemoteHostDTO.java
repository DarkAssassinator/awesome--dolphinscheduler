package org.apache.dolphinscheduler.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
public class TaskRemoteHostDTO {

    @Schema(example = "app01", description = "task remote host name", required = true)
    private String name;

    @Schema(example = "127.0.0.1", description = "task remote host ip", required = true)
    private String ip;

    @Schema(example = "22",implementation = int.class, description = "task remote host SSH port, default 22", required = true)
    private int port;

    @Schema(example = "foo", description = "task remote host account", required = true)
    private String account;

    @Schema(example = "foo", description = "task remote host account's password", required = true)
    private String password;

    @Schema(example = "this is a demo host", description = "task remote host account's password")
    private String description;

}
