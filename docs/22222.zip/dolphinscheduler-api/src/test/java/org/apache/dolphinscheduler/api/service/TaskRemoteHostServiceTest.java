package org.apache.dolphinscheduler.api.service;

import org.apache.dolphinscheduler.api.permission.ResourcePermissionCheckService;
import org.apache.dolphinscheduler.api.service.impl.TaskRemoteHostServiceImpl;
import org.apache.dolphinscheduler.dao.mapper.TaskRemoteHostMapper;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TaskRemoteHostServiceTest {

    @InjectMocks
    private TaskRemoteHostServiceImpl taskRemoteHostService;

    @Mock
    private TaskRemoteHostMapper taskRemoteHostMapper;

    @Mock
    private ResourcePermissionCheckService resourcePermissionCheckService;


}
